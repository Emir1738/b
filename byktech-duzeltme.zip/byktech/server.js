'use strict';
/* BykTech — statik site + POST /api/chat (sıfır bağımlılık, Node >= 18)
   - OPENAI_API_KEY varsa OpenAI'ye sorar; yoksa/erişilemezse site-content.json
     tabanlı yerel motorla cevap verir. Kullanıcıya asla boş cevap dönmez.
   - API anahtarı yalnızca sunucuda tutulur, tarayıcıya hiç gitmez. */
const http = require('http');
const fs = require('fs');
const path = require('path');

// --- .env (dotenv paketi olmadan, basit ayrıştırıcı) ---
try {
  for (const line of fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/i);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
} catch { /* .env yoksa sorun değil: yerel modda çalışır */ }

const PORT = Number(process.env.PORT || 3000);
const API_KEY = (Object.entries(process.env).find(([k]) => k.endsWith('_API_KEY')) || [])[1] || ''; // .env icindeki *_API_KEY anahtari
const MODEL = process.env.OPENAI_MODEL || 'gpt-4o-mini';
const CORS_ORIGIN = process.env.CORS_ORIGIN || '';
const ROOT = __dirname;

const SYSTEM_PROMPT = `Sen BykTech Destek Asistanısın. Yalnızca sana verilen SITE İÇERİĞİ'ne dayanarak, kısa ve net cevap ver.
Kurallar: Bilmediğini uydurma; bilinmeyen konuda kullanıcıyı İletişim bölümüne (WhatsApp/Telegram/Bionluk/Fiverr) yönlendir.
Konu dışına çıkma; hizmetler, çalışma süreci, portföy, teknoloji, güvenlik ve iletişim dışındaki soruları kibarca bu kapsama çek.
Cevap dili kullanıcının diliyle aynı olsun. En fazla 120 kelime.`;

let KNOWLEDGE = { faq: [], unknown: { tr: 'Bu konuda net bilgi için lütfen İletişim bölümünden doğrudan yazın.', en: 'Please get in touch via the Contact section for details on that.' } };
try { KNOWLEDGE = JSON.parse(fs.readFileSync(path.join(ROOT, 'site-content.json'), 'utf8')); } catch (e) { console.error('site-content.json okunamadı:', e.message); }

const fold = (v) => String(v).replace(/İ/g, 'i').replace(/I/g, 'ı').replace(/Ş/g, 'ş').replace(/Ğ/g, 'ğ').replace(/Ü/g, 'ü').replace(/Ö/g, 'ö').replace(/Ç/g, 'ç').toLowerCase();
function localAnswer(question, lang = 'tr') {
  const hay = fold(question);
  let best = null, bestScore = 0;
  for (const e of KNOWLEDGE.faq || []) {
    let score = 0;
    for (const k of e.keywords || []) { const n = fold(k); if (n && hay.includes(n)) score += n.length; }
    if (score > bestScore) { bestScore = score; best = e; }
  }
  if (best?.answer) return best.answer[lang] || best.answer.tr;
  return (KNOWLEDGE.unknown && (KNOWLEDGE.unknown[lang] || KNOWLEDGE.unknown.tr)) || 'Lütfen İletişim bölümünden doğrudan yazın.';
}

async function askOpenAI(message, language, history) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 15000); // 15 sn timeout
  try {
    const messages = [
      { role: 'system', content: SYSTEM_PROMPT + '\n\nSITE İÇERİĞİ:\n' + JSON.stringify(KNOWLEDGE) },
      ...history, { role: 'user', content: message },
    ];
    const r = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST', signal: ctrl.signal,
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${API_KEY}` },
      body: JSON.stringify({ model: MODEL, temperature: 0.2, top_p: 0.9, max_tokens: 400, messages }),
    });
    if (!r.ok) throw new Error(`OpenAI HTTP ${r.status}`);
    const data = await r.json();
    const reply = data.choices?.[0]?.message?.content?.trim();
    if (!reply) throw new Error('OpenAI boş cevap döndü');
    return reply;
  } finally { clearTimeout(timer); }
}

// Basit hız sınırı: IP başına dakikada 20 istek
const hits = new Map();
function rateLimited(ip) {
  const now = Date.now(), arr = (hits.get(ip) || []).filter((t) => now - t < 60000);
  arr.push(now); hits.set(ip, arr); return arr.length > 20;
}

const MIME = { '.html': 'text/html; charset=utf-8', '.json': 'application/json; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };
function sendJson(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', ...(CORS_ORIGIN ? { 'Access-Control-Allow-Origin': CORS_ORIGIN } : {}) });
  res.end(body);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  if (req.method === 'OPTIONS') { res.writeHead(204, CORS_ORIGIN ? { 'Access-Control-Allow-Origin': CORS_ORIGIN, 'Access-Control-Allow-Methods': 'POST,GET', 'Access-Control-Allow-Headers': 'Content-Type' } : {}); return res.end(); }
  if (url.pathname === '/health') return sendJson(res, 200, { ok: true, aiConfigured: Boolean(API_KEY) });

  if (url.pathname === '/api/chat') {
    if (req.method !== 'POST') return sendJson(res, 405, { error: 'Yalnızca POST desteklenir.' });
    if (rateLimited(req.socket.remoteAddress || '?')) return sendJson(res, 429, { error: 'Çok hızlı mesaj gönderiyorsunuz. Lütfen biraz bekleyip tekrar deneyin.' });
    let raw = '';
    req.on('data', (c) => { raw += c; if (raw.length > 32768) req.destroy(); });
    req.on('end', async () => {
      let body; try { body = JSON.parse(raw || '{}'); } catch { return sendJson(res, 400, { error: 'Geçersiz JSON.' }); }
      // Frontend {message, language, history} gönderir; {messages:[...]} biçimi de kabul edilir.
      let message = typeof body.message === 'string' ? body.message.trim() : '';
      if (!message && Array.isArray(body.messages)) { const last = [...body.messages].reverse().find((m) => m?.role === 'user'); message = String(last?.content || '').trim(); }
      const language = body.language === 'en' ? 'en' : 'tr';
      const history = (Array.isArray(body.history) ? body.history : [])
        .filter((m) => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
        .slice(-8).map((m) => ({ role: m.role, content: m.content.slice(0, 800) }));
      if (!message) return sendJson(res, 400, { error: language === 'en' ? 'Please type a short question first.' : 'Önce kısa bir soru yazın.' });
      if (message.length > 800) return sendJson(res, 400, { error: language === 'en' ? 'Messages can be at most 800 characters.' : 'Mesaj en fazla 800 karakter olabilir.' });
      try {
        if (API_KEY) {
          try { return sendJson(res, 200, { reply: await askOpenAI(message, language, history), mode: 'ai' }); }
          catch (e) { console.error('Chat API hatası:', e.message); /* yedeğe düş, kullanıcı cevapsız kalmasın */ }
        }
        return sendJson(res, 200, { reply: localAnswer(message, language), mode: 'ai' });
      } catch (e) {
        console.error('Chat API hatası:', e);
        return sendJson(res, 500, { error: language === 'en' ? "I can't respond right now. Please try again or get in touch directly." : 'Şu an cevap veremiyorum, lütfen tekrar deneyin ya da doğrudan iletişime geçin.' });
      }
    });
    return;
  }

  // Statik dosyalar (yol aşımına kapalı)
  const rel = url.pathname === '/' ? 'index.html' : url.pathname.replace(/^\/+/, '');
  const file = path.join(ROOT, rel);
  if (!file.startsWith(ROOT) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('404 Not Found'); }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' });
  fs.createReadStream(file).pipe(res);
});

server.listen(PORT, '0.0.0.0', () => console.log(`BykTech sunucusu çalışıyor: http://0.0.0.0:${PORT} (AI: ${API_KEY ? MODEL : 'yerel mod — OPENAI_API_KEY yok'})`));
